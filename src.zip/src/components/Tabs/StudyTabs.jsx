import * as Tabs from "@radix-ui/react-tabs";
import styles from "./Tabs.module.css";
import { useFilter } from "../../context/FilterContext";
import React, { useEffect } from "react";
import TabsContent from "./TabsContent";
import {
  useStudyData,
  useStudyDataDispatch,
} from "../../features/studies/context/StudyDataContext";

const StudyTabs = ({ study }) => {
  const { studyData } = study || {};
  const dispatch = useStudyDataDispatch(); // ✅ Context dispatcher

  const { activeFilter, activeVisualization } = useFilter();

  useEffect(() => {
    console.log("✅ studyData extracted:", studyData);
    console.log("Study from tabs component:", study);
    console.log("Current Active Filter:", activeFilter);
    console.log("Current Active Visualization:", activeVisualization);
  }, [studyData, activeFilter, activeVisualization]);

  // ✅ Dispatch tab selection and data slices into global context
  const handleTabChange = (tabLabel, tabKey) => {
    const topDown = studyData[`(T) ${tabLabel}`];
    const bottomDown = studyData[`(B) ${tabLabel}`];
    const responseTime = studyData[`(R) ${tabLabel}`];

    dispatch({
      type: "SET_GRID_DATA",
      payload: {
        tab: tabKey,
        datasets: {
          TopDown: topDown?.Data?.Questions ?? [],
          BottomUp: bottomDown?.Data?.Questions ?? [],
          ResponseTime: responseTime?.Data?.Questions ?? [],
        },
      },
    });
  };

  // If studyData is still loading
  if (!studyData) {
    return <p>Loading study data ...</p>;
  }

  return (
    <Tabs.Root
      defaultValue="overall"
      className={styles.tabsContainer}
      onValueChange={(value) => {
        switch (value) {
          case "overall":
            handleTabChange("Overall", "overall");
            break;
          case "age":
            handleTabChange("Age segments", "age");
            break;
          case "gender":
            handleTabChange("Gender segments", "gender");
            break;
          case "prelim":
            handleTabChange("Prelim-answer segments", "prelim");
            break;
          case "2 market segments":
            handleTabChange("Mindsets", "2Mindsets");
            break;
          case "3 market segments":
            handleTabChange("Mindsets", "3Mindsets");
            break;
          default:
            break;
        }
      }}
    >
      <Tabs.List className={styles.tabsList}>
        <Tabs.Trigger value="overall" className={styles.tabTrigger}>
          Overall
        </Tabs.Trigger>
        <Tabs.Trigger value="age" className={styles.tabTrigger}>
          Age
        </Tabs.Trigger>
        <Tabs.Trigger value="gender" className={styles.tabTrigger}>
          Gender
        </Tabs.Trigger>
        <Tabs.Trigger value="prelim" className={styles.tabTrigger}>
          Prelim
        </Tabs.Trigger>
        <Tabs.Trigger value="2 market segments" className={styles.tabTrigger}>
          2 Market Segments
        </Tabs.Trigger>
        <Tabs.Trigger value="3 market segments" className={styles.tabTrigger}>
          3 Market Segments
        </Tabs.Trigger>
      </Tabs.List>

      {/* 🔁 Each tab still passes its props to TabsContent for heatmap/table */}
      <Tabs.Content value="overall" className={styles.tabContent}>
        <TabsContent
          tab="overall"
          topDown={studyData["(T) Overall"]}
          bottomDown={studyData["(B) Overall"]}
          responseTime={studyData["(R) Overall"]}
        />
      </Tabs.Content>
      <Tabs.Content value="age" className={styles.tabContent}>
        <TabsContent
          tab="Age Segments"
          topDown={studyData["(T) Age segments"]}
          bottomDown={studyData["(B) Age segments"]}
          responseTime={studyData["(R) Age segments"]}
        />
      </Tabs.Content>
      <Tabs.Content value="gender" className={styles.tabContent}>
        <TabsContent
          tab="Gender Segments"
          topDown={studyData["(T) Gender segments"]}
          bottomDown={studyData["(B) Gender segments"]}
          responseTime={studyData["(R) Gender segments"]}
        />
      </Tabs.Content>
      <Tabs.Content value="prelim" className={styles.tabContent}>
        <TabsContent
          tab="Prelim-Answer Segments"
          topDown={studyData["(T) Prelim-answer segments"]}
          bottomDown={studyData["(B) Prelim-answer segments"]}
          responseTime={studyData["(R) Prelim-answer segments"]}
        />
      </Tabs.Content>
      <Tabs.Content value="2 market segments" className={styles.tabContent}>
        <TabsContent
          tab="2Mindsets"
          topDown={studyData["(T) Mindsets"]}
          bottomDown={studyData["(B) Mindsets"]}
          responseTime={studyData["(R) Mindsets"]}
        />
      </Tabs.Content>
      <Tabs.Content value="3 market segments" className={styles.tabContent}>
        <TabsContent
          tab="3Mindsets"
          topDown={studyData["(T) Mindsets"]}
          bottomDown={studyData["(B) Mindsets"]}
          responseTime={studyData["(R) Mindsets"]}
        />
      </Tabs.Content>
    </Tabs.Root>
  );
};

export default StudyTabs;
