import React, { createContext, useReducer, useContext } from "react";
import {
  studyDataReducer,
  initialDataState,
} from "../reducers/studyDataReducer";

const StudyDataContext = createContext();
const StudyDataDispatchContext = createContext();

export const StudyDataProvider = ({ children }) => {
  const [state, dispatch] = useReducer(studyDataReducer, initialDataState);

  return (
    <StudyDataContext.Provider value={state}>
      <StudyDataDispatchContext.Provider value={dispatch}>
        {children}
      </StudyDataDispatchContext.Provider>
    </StudyDataContext.Provider>
  );
};

export const useStudyData = () => useContext(StudyDataContext);
export const useStudyDataDispatch = () => useContext(StudyDataDispatchContext);
