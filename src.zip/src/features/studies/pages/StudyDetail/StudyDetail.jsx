import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useStudy } from "../../hooks/useStudy";
import Spinner from "../../../../components/common/Spinner";
import StudyTabs from "../../../../components/Tabs/StudyTabs";
import ExportPage from "../../../../components/ExportButton/ExportButton";
import StudyFilters from "../../../../components/Tabs/StudyFilters";
import { FilterProvider } from "../../../../context/FilterContext";
import {
  StudyDataProvider,
  useStudyDataDispatch,
} from "../../context/StudyDataContext";

import styles from "./StudyDetail.module.css";

// 🔁 Child component that lives inside StudyDataProvider
const StudyContent = ({ study }) => {
  console.log("Study raw data:", study?.studyData);
  const dispatch = useStudyDataDispatch();

  useEffect(() => {
    const data = study?.studyData;
    if (
      data &&
      data["(T) Overall"]?.Data &&
      data["(B) Overall"]?.Data &&
      data["(R) Overall"]?.Data
    ) {
      dispatch({
        type: "SET_GRID_DATA",
        payload: {
          tab: "overall", // match TabsContent and StudyGrid usage
          datasets: {
            TopDown: data["(T) Overall"].Data,
            BottomUp: data["(B) Overall"].Data,
            ResponseTime: data["(R) Overall"].Data,
          },
        },
      });
    } else {
      console.warn("One or more datasets are missing:", data);
    }
  }, [study]);

  return (
    <div className="container">
      <div className={styles.studyHeader}>
        <h1 className={styles.studyTitle}>{study.studyTitle}</h1>
        <ExportPage />
      </div>

      <div className={styles.studyMetadata}>
        <p>
          Status:{" "}
          <span className={styles.studyRespondents}>
            {study.studyStatus === "ongoing"
              ? "Ongoing"
              : "Completed on: " + study.studyStatus}
          </span>
        </p>
        <p>
          Surveys Started: <span>{study.studyStarted}</span>
        </p>
        <p>
          Surveys Completed:{" "}
          <span className={styles.studyRespondents}>
            {study.studyRespondents}
          </span>{" "}
          (out of {study.studyRespondents})
        </p>
      </div>

      <StudyFilters />
      <StudyTabs study={study} />
    </div>
  );
};

const StudyDetail = () => {
  const { id } = useParams();
  const { study, loading } = useStudy(id);

  if (loading) {
    return (
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
        }}
      >
        <Spinner />
      </div>
    );
  }

  if (!study) return <h1>Study not found</h1>;

  return (
    <div id="page-content">
      <FilterProvider>
        <StudyDataProvider>
          <StudyContent study={study} />
        </StudyDataProvider>
      </FilterProvider>
    </div>
  );
};

export default StudyDetail;
