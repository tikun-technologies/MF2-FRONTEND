import { useEffect, useState, useContext } from "react";
import { getStudy } from "../api/getStudies";
import AuthContext from "../../../context/AuthContext";

export const useStudy = (id) => {
  const { token } = useContext(AuthContext);
  const [study, setStudy] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await getStudy(id, token);
        setStudy(res.study);
      } catch (e) {
        console.error("Fetch failed:", e);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [id, token]);

  return { study, loading };
};
