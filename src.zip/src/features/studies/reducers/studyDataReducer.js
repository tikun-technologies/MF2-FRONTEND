export const initialDataState = {
  currentTab: "overall",
  datasets: {
    TopDown: [],
    BottomUp: [],
    ResponseTime: [],
    Mindsets: [],
  },
};

export const studyDataReducer = (state, action) => {
  console.log("Reducer Called:", action);
  switch (action.type) {
    case "SET_GRID_DATA":
      return {
        ...state,
        currentTab: action.payload.tab,
        datasets: {
          TopDown: action.payload.datasets.TopDown || [],
          BottomUp: action.payload.datasets.BottomUp || [],
          ResponseTime: action.payload.datasets.ResponseTime || [],
          Mindsets: action.payload.datasets.Mindsets || [],
        },
      };

    // Add future cases here like SET_MINDSETS, RESET_GRID, etc.

    default:
      return state;
  }
};
