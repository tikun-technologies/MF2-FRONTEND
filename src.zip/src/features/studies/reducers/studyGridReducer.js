export const initialState = {
  activeTab: "Overall",
  selectedView: "Top Down", // or "Bottom Up", "Response Time", etc.
  gridData: [],
};

export function studyGridReducer(state, action) {
  switch (action.type) {
    case "SET_TAB":
      return { ...state, activeTab: action.payload };
    case "SET_VIEW":
      return { ...state, selectedView: action.payload };
    case "SET_DATA":
      return { ...state, gridData: action.payload };
    default:
      return state;
  }
}
